/**
 * AuthMaster Utilities
 * @forgedevstack/forge-auth
 */

export { logger } from './logger';
