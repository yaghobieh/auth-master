import React, { useState } from 'react';
import { Card, Typography, Switch, Input, Button, Flex, Divider, Tabs, TabList, Tab, TabPanel } from '@forgedevstack/bear';

const Settings: React.FC = () => {
  const [sessionTimeout, setSessionTimeout] = useState('60');
  const [minPasswordLength, setMinPasswordLength] = useState('8');
  const [maxLoginAttempts, setMaxLoginAttempts] = useState('5');
  
  const [googleEnabled, setGoogleEnabled] = useState(true);
  const [facebookEnabled, setFacebookEnabled] = useState(false);
  const [githubEnabled, setGithubEnabled] = useState(true);
  const [emailEnabled, setEmailEnabled] = useState(true);
  
  const [require2FA, setRequire2FA] = useState(false);
  const [emailVerification, setEmailVerification] = useState(true);

  return (
    <div className="space-y-6">
      <div>
        <Typography variant="h4" className="font-bold mb-1">Settings</Typography>
        <Typography variant="body2" className="text-gray-400">
          Configure authentication settings and security policies
        </Typography>
      </div>

      <Tabs defaultValue="general">
        <TabList className="mb-6">
          <Tab value="general">General</Tab>
          <Tab value="providers">Providers</Tab>
          <Tab value="security">Security</Tab>
          <Tab value="branding">Branding</Tab>
        </TabList>

        <TabPanel value="general">
          <Card className="p-6 bg-gray-800/50 border border-gray-700">
            <Typography variant="h6" className="font-bold mb-4">Session Settings</Typography>
            
            <div className="space-y-4 max-w-md">
              <div>
                <Typography variant="body2" className="mb-1.5 font-medium">
                  Session Timeout (minutes)
                </Typography>
                <Input
                  type="number"
                  value={sessionTimeout}
                  onChange={(e) => setSessionTimeout(e.target.value)}
                  fullWidth
                />
              </div>

              <Flex justify="between" align="center">
                <div>
                  <Typography variant="body2" className="font-medium">Remember Me</Typography>
                  <Typography variant="caption" className="text-gray-400">
                    Allow users to stay signed in
                  </Typography>
                </div>
                <Switch defaultChecked />
              </Flex>

              <Flex justify="between" align="center">
                <div>
                  <Typography variant="body2" className="font-medium">Single Session</Typography>
                  <Typography variant="caption" className="text-gray-400">
                    Only allow one active session per user
                  </Typography>
                </div>
                <Switch />
              </Flex>
            </div>

            <Divider className="my-6" />

            <Button variant="primary">Save Changes</Button>
          </Card>
        </TabPanel>

        <TabPanel value="providers">
          <Card className="p-6 bg-gray-800/50 border border-gray-700">
            <Typography variant="h6" className="font-bold mb-4">Authentication Providers</Typography>
            
            <div className="space-y-4">
              <Flex justify="between" align="center" className="p-4 rounded-lg bg-gray-700/30">
                <Flex gap="md" align="center">
                  <span className="text-2xl">📧</span>
                  <div>
                    <Typography variant="body1" className="font-medium">Email/Password</Typography>
                    <Typography variant="caption" className="text-gray-400">
                      Traditional email and password authentication
                    </Typography>
                  </div>
                </Flex>
                <Switch checked={emailEnabled} onChange={setEmailEnabled} />
              </Flex>

              <Flex justify="between" align="center" className="p-4 rounded-lg bg-gray-700/30">
                <Flex gap="md" align="center">
                  <span className="text-2xl">🔵</span>
                  <div>
                    <Typography variant="body1" className="font-medium">Google</Typography>
                    <Typography variant="caption" className="text-gray-400">
                      OAuth 2.0 with Google accounts
                    </Typography>
                  </div>
                </Flex>
                <Switch checked={googleEnabled} onChange={setGoogleEnabled} />
              </Flex>

              <Flex justify="between" align="center" className="p-4 rounded-lg bg-gray-700/30">
                <Flex gap="md" align="center">
                  <span className="text-2xl">⚫</span>
                  <div>
                    <Typography variant="body1" className="font-medium">GitHub</Typography>
                    <Typography variant="caption" className="text-gray-400">
                      OAuth with GitHub accounts
                    </Typography>
                  </div>
                </Flex>
                <Switch checked={githubEnabled} onChange={setGithubEnabled} />
              </Flex>

              <Flex justify="between" align="center" className="p-4 rounded-lg bg-gray-700/30">
                <Flex gap="md" align="center">
                  <span className="text-2xl">🔷</span>
                  <div>
                    <Typography variant="body1" className="font-medium">Facebook</Typography>
                    <Typography variant="caption" className="text-gray-400">
                      OAuth with Facebook accounts
                    </Typography>
                  </div>
                </Flex>
                <Switch checked={facebookEnabled} onChange={setFacebookEnabled} />
              </Flex>
            </div>

            <Divider className="my-6" />

            <Button variant="primary">Save Changes</Button>
          </Card>
        </TabPanel>

        <TabPanel value="security">
          <Card className="p-6 bg-gray-800/50 border border-gray-700">
            <Typography variant="h6" className="font-bold mb-4">Security Settings</Typography>
            
            <div className="space-y-4 max-w-md">
              <div>
                <Typography variant="body2" className="mb-1.5 font-medium">
                  Minimum Password Length
                </Typography>
                <Input
                  type="number"
                  value={minPasswordLength}
                  onChange={(e) => setMinPasswordLength(e.target.value)}
                  fullWidth
                />
              </div>

              <div>
                <Typography variant="body2" className="mb-1.5 font-medium">
                  Max Login Attempts Before Lockout
                </Typography>
                <Input
                  type="number"
                  value={maxLoginAttempts}
                  onChange={(e) => setMaxLoginAttempts(e.target.value)}
                  fullWidth
                />
              </div>

              <Flex justify="between" align="center">
                <div>
                  <Typography variant="body2" className="font-medium">Require 2FA</Typography>
                  <Typography variant="caption" className="text-gray-400">
                    Require two-factor authentication for all users
                  </Typography>
                </div>
                <Switch checked={require2FA} onChange={setRequire2FA} />
              </Flex>

              <Flex justify="between" align="center">
                <div>
                  <Typography variant="body2" className="font-medium">Email Verification</Typography>
                  <Typography variant="caption" className="text-gray-400">
                    Require email verification on sign up
                  </Typography>
                </div>
                <Switch checked={emailVerification} onChange={setEmailVerification} />
              </Flex>
            </div>

            <Divider className="my-6" />

            <Button variant="primary">Save Changes</Button>
          </Card>
        </TabPanel>

        <TabPanel value="branding">
          <Card className="p-6 bg-gray-800/50 border border-gray-700">
            <Typography variant="h6" className="font-bold mb-4">Branding</Typography>
            
            <div className="space-y-4 max-w-md">
              <div>
                <Typography variant="body2" className="mb-1.5 font-medium">
                  Application Name
                </Typography>
                <Input defaultValue="AuthMaster" fullWidth />
              </div>

              <div>
                <Typography variant="body2" className="mb-1.5 font-medium">
                  Primary Color
                </Typography>
                <Input type="color" defaultValue="#ec4899" className="h-10 w-20" />
              </div>

              <div>
                <Typography variant="body2" className="mb-1.5 font-medium">
                  Logo URL
                </Typography>
                <Input placeholder="https://example.com/logo.png" fullWidth />
              </div>

              <div>
                <Typography variant="body2" className="mb-1.5 font-medium">
                  Support Email
                </Typography>
                <Input placeholder="support@example.com" fullWidth />
              </div>
            </div>

            <Divider className="my-6" />

            <Button variant="primary">Save Changes</Button>
          </Card>
        </TabPanel>
      </Tabs>
    </div>
  );
};

export default Settings;
