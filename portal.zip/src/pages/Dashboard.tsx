import React from 'react';
import { Card, Typography, StatCard, Flex, Grid } from '@forgedevstack/bear';
import { useAuth } from '@forgedevstack/forge-auth';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  const stats = [
    { label: 'Total Users', value: '1,234', change: '+12%', icon: '👥' },
    { label: 'Active Sessions', value: '89', change: '+5%', icon: '🔗' },
    { label: 'Auth Events (24h)', value: '456', change: '+8%', icon: '📊' },
    { label: 'Failed Logins', value: '12', change: '-3%', icon: '⚠️' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <Typography variant="h4" className="font-bold mb-1">
          Welcome back, {user?.name || 'Admin'}
        </Typography>
        <Typography variant="body2" className="text-gray-400">
          Here's what's happening with your authentication system
        </Typography>
      </div>

      <Grid cols={4} gap="md">
        {stats.map((stat) => (
          <Card key={stat.label} className="p-5 bg-gray-800/50 border border-gray-700">
            <Flex justify="between" align="start" className="mb-3">
              <span className="text-2xl">{stat.icon}</span>
              <span className={`text-sm ${stat.change.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
                {stat.change}
              </span>
            </Flex>
            <Typography variant="h4" className="font-bold mb-1">
              {stat.value}
            </Typography>
            <Typography variant="body2" className="text-gray-400">
              {stat.label}
            </Typography>
          </Card>
        ))}
      </Grid>

      <Grid cols={2} gap="md">
        <Card className="p-6 bg-gray-800/50 border border-gray-700">
          <Typography variant="h6" className="font-bold mb-4">
            Recent Activity
          </Typography>
          <div className="space-y-3">
            {[
              { action: 'Sign in', user: 'john@example.com', time: '2 min ago', status: 'success' },
              { action: 'Sign up', user: 'jane@example.com', time: '15 min ago', status: 'success' },
              { action: 'Failed login', user: 'unknown@test.com', time: '1 hour ago', status: 'error' },
              { action: 'Password reset', user: 'bob@example.com', time: '3 hours ago', status: 'success' },
            ].map((item, i) => (
              <Flex key={i} justify="between" align="center" className="py-2 border-b border-gray-700 last:border-0">
                <Flex gap="sm" align="center">
                  <span className={`w-2 h-2 rounded-full ${item.status === 'success' ? 'bg-green-400' : 'bg-red-400'}`} />
                  <div>
                    <Typography variant="body2" className="font-medium">{item.action}</Typography>
                    <Typography variant="caption" className="text-gray-400">{item.user}</Typography>
                  </div>
                </Flex>
                <Typography variant="caption" className="text-gray-500">{item.time}</Typography>
              </Flex>
            ))}
          </div>
        </Card>

        <Card className="p-6 bg-gray-800/50 border border-gray-700">
          <Typography variant="h6" className="font-bold mb-4">
            Auth Providers
          </Typography>
          <div className="space-y-4">
            {[
              { name: 'Email/Password', users: 890, enabled: true },
              { name: 'Google', users: 234, enabled: true },
              { name: 'GitHub', users: 87, enabled: true },
              { name: 'Facebook', users: 23, enabled: false },
            ].map((provider) => (
              <Flex key={provider.name} justify="between" align="center">
                <Flex gap="sm" align="center">
                  <span className={`w-3 h-3 rounded-full ${provider.enabled ? 'bg-green-400' : 'bg-gray-500'}`} />
                  <Typography variant="body2">{provider.name}</Typography>
                </Flex>
                <Typography variant="body2" className="text-gray-400">
                  {provider.users} users
                </Typography>
              </Flex>
            ))}
          </div>
        </Card>
      </Grid>
    </div>
  );
};

export default Dashboard;
