import React from 'react';
import { Navigate } from 'react-router-dom';
import { Card, Typography } from '@forgedevstack/bear';
import { EmailForm, useAuth, GuestGuard } from '@forgedevstack/forge-auth';

const Login: React.FC = () => {
  const { isAuthenticated } = useAuth();

  if (isAuthenticated) {
    return <Navigate to="/dashboard" />;
  }

  return (
    <GuestGuard fallback={<Navigate to="/dashboard" />}>
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 p-4">
        <Card className="w-full max-w-md p-8 bg-gray-800/50 backdrop-blur border border-gray-700">
          <div className="text-center mb-8">
            <span className="text-5xl mb-4 block">🔐</span>
            <Typography variant="h4" className="gradient-text font-bold mb-2">
              AuthMaster Portal
            </Typography>
            <Typography variant="body2" className="text-gray-400">
              Sign in to access the admin dashboard
            </Typography>
          </div>

          <EmailForm />

          <div className="mt-6 text-center">
            <Typography variant="caption" className="text-gray-500">
              Part of the ForgeStack ecosystem
            </Typography>
          </div>
        </Card>
      </div>
    </GuestGuard>
  );
};

export default Login;
