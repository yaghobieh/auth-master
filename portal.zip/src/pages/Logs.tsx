import React, { useState } from 'react';
import { Card, Typography, Select, Badge, Flex, Button } from '@forgedevstack/bear';
import { GridTable, ColumnDefinition } from '@forgedevstack/grid-table';

interface AuthLog {
  id: string;
  timestamp: string;
  event: string;
  email: string;
  ip: string;
  userAgent: string;
  status: 'success' | 'failure';
  details: string;
}

const mockLogs: AuthLog[] = [
  { id: '1', timestamp: '2024-02-08 12:45:32', event: 'sign_in', email: 'john@example.com', ip: '192.168.1.100', userAgent: 'Chrome/120', status: 'success', details: 'Email login successful' },
  { id: '2', timestamp: '2024-02-08 12:30:15', event: 'sign_up', email: 'newuser@example.com', ip: '10.0.0.50', userAgent: 'Firefox/121', status: 'success', details: 'New account created' },
  { id: '3', timestamp: '2024-02-08 12:15:00', event: 'sign_in', email: 'unknown@test.com', ip: '192.168.1.200', userAgent: 'Safari/17', status: 'failure', details: 'Invalid credentials' },
  { id: '4', timestamp: '2024-02-08 11:45:20', event: 'password_reset', email: 'bob@example.com', ip: '172.16.0.1', userAgent: 'Chrome/120', status: 'success', details: 'Password reset email sent' },
  { id: '5', timestamp: '2024-02-08 11:30:00', event: 'sign_out', email: 'alice@example.com', ip: '192.168.1.150', userAgent: 'Edge/120', status: 'success', details: 'User signed out' },
  { id: '6', timestamp: '2024-02-08 11:00:00', event: 'oauth_callback', email: 'jane@example.com', ip: '10.0.0.75', userAgent: 'Chrome/120', status: 'success', details: 'Google OAuth successful' },
  { id: '7', timestamp: '2024-02-08 10:45:00', event: 'sign_in', email: 'hacker@bad.com', ip: '45.33.32.156', userAgent: 'curl/7.68', status: 'failure', details: 'Rate limited' },
];

const Logs: React.FC = () => {
  const [filter, setFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const columns: ColumnDefinition<AuthLog>[] = [
    { id: 'timestamp', accessor: 'timestamp', header: 'Timestamp', sortable: true },
    { 
      id: 'event',
      accessor: 'event', 
      header: 'Event',
      render: (val) => (
        <Badge variant="default" className="capitalize">
          {String(val).replace('_', ' ')}
        </Badge>
      ),
    },
    { id: 'email', accessor: 'email', header: 'Email', sortable: true },
    { id: 'ip', accessor: 'ip', header: 'IP Address' },
    { 
      id: 'status',
      accessor: 'status', 
      header: 'Status',
      render: (val) => (
        <Badge variant={val === 'success' ? 'success' : 'danger'}>
          {String(val)}
        </Badge>
      ),
    },
    { id: 'details', accessor: 'details', header: 'Details' },
  ];

  const filteredLogs = mockLogs.filter((log) => {
    if (filter !== 'all' && log.event !== filter) return false;
    if (statusFilter !== 'all' && log.status !== statusFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <div>
        <Typography variant="h4" className="font-bold mb-1">Authentication Logs</Typography>
        <Typography variant="body2" className="text-gray-400">
          Monitor all authentication events in real-time
        </Typography>
      </div>

      <Card className="p-6 bg-gray-800/50 border border-gray-700">
        <Flex gap="md" className="mb-6">
          <Select
            value={filter}
            onChange={(val) => setFilter(val as string)}
            options={[
              { value: 'all', label: 'All Events' },
              { value: 'sign_in', label: 'Sign In' },
              { value: 'sign_up', label: 'Sign Up' },
              { value: 'sign_out', label: 'Sign Out' },
              { value: 'password_reset', label: 'Password Reset' },
              { value: 'oauth_callback', label: 'OAuth Callback' },
            ]}
            className="w-48"
          />
          <Select
            value={statusFilter}
            onChange={(val) => setStatusFilter(val as string)}
            options={[
              { value: 'all', label: 'All Status' },
              { value: 'success', label: 'Success' },
              { value: 'failure', label: 'Failure' },
            ]}
            className="w-48"
          />
          <Button variant="outline">Export CSV</Button>
          <Button variant="ghost">Clear Filters</Button>
        </Flex>

        <GridTable
          data={filteredLogs}
          columns={columns}
          showPagination
          paginationConfig={{ pageSize: 20 }}
        />
      </Card>
    </div>
  );
};

export default Logs;
