import React, { useState } from 'react';
import { Card, Typography, Input, Button, Badge, Flex, Modal } from '@forgedevstack/bear';
import { GridTable, ColumnDefinition } from '@forgedevstack/grid-table';

interface User {
  id: string;
  email: string;
  name: string;
  provider: string;
  status: 'active' | 'inactive' | 'banned';
  lastLogin: string;
  createdAt: string;
}

const mockUsers: User[] = [
  { id: '1', email: 'john@example.com', name: 'John Doe', provider: 'email', status: 'active', lastLogin: '2 hours ago', createdAt: '2024-01-15' },
  { id: '2', email: 'jane@example.com', name: 'Jane Smith', provider: 'google', status: 'active', lastLogin: '1 day ago', createdAt: '2024-02-20' },
  { id: '3', email: 'bob@example.com', name: 'Bob Wilson', provider: 'github', status: 'inactive', lastLogin: '1 week ago', createdAt: '2024-03-10' },
  { id: '4', email: 'alice@example.com', name: 'Alice Brown', provider: 'email', status: 'active', lastLogin: '5 min ago', createdAt: '2024-01-05' },
  { id: '5', email: 'charlie@example.com', name: 'Charlie Davis', provider: 'facebook', status: 'banned', lastLogin: '2 months ago', createdAt: '2023-12-01' },
];

const Users: React.FC = () => {
  const [search, setSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  const columns: ColumnDefinition<User>[] = [
    { id: 'name', accessor: 'name', header: 'Name', sortable: true },
    { id: 'email', accessor: 'email', header: 'Email', sortable: true },
    { 
      id: 'provider',
      accessor: 'provider', 
      header: 'Provider',
      render: (val) => (
        <Badge variant={val === 'email' ? 'default' : 'primary'}>
          {String(val)}
        </Badge>
      ),
    },
    { 
      id: 'status',
      accessor: 'status', 
      header: 'Status',
      render: (val) => (
        <Badge 
          variant={val === 'active' ? 'success' : val === 'banned' ? 'danger' : 'warning'}
        >
          {String(val)}
        </Badge>
      ),
    },
    { id: 'lastLogin', accessor: 'lastLogin', header: 'Last Login' },
    {
      id: 'actions',
      accessor: 'id',
      header: 'Actions',
      render: (_val, row) => (
        <Button variant="ghost" size="sm" onClick={() => setSelectedUser(row as User)}>
          View
        </Button>
      ),
    },
  ];

  const filteredUsers = mockUsers.filter(
    (u) => u.name.toLowerCase().includes(search.toLowerCase()) || 
           u.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <Flex justify="between" align="center">
        <div>
          <Typography variant="h4" className="font-bold mb-1">Users</Typography>
          <Typography variant="body2" className="text-gray-400">
            Manage user accounts and permissions
          </Typography>
        </div>
        <Button variant="primary">Add User</Button>
      </Flex>

      <Card className="p-6 bg-gray-800/50 border border-gray-700">
        <Flex gap="md" className="mb-6">
          <Input
            placeholder="Search users..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-sm"
          />
          <Button variant="outline">Filter</Button>
          <Button variant="outline">Export</Button>
        </Flex>

        <GridTable
          data={filteredUsers}
          columns={columns}
          showPagination
          paginationConfig={{ pageSize: 10 }}
        />
      </Card>

      <Modal
        open={!!selectedUser}
        onClose={() => setSelectedUser(null)}
        title="User Details"
      >
        {selectedUser && (
          <div className="space-y-4 p-4">
            <div>
              <Typography variant="caption" className="text-gray-400">Name</Typography>
              <Typography variant="body1">{selectedUser.name}</Typography>
            </div>
            <div>
              <Typography variant="caption" className="text-gray-400">Email</Typography>
              <Typography variant="body1">{selectedUser.email}</Typography>
            </div>
            <div>
              <Typography variant="caption" className="text-gray-400">Provider</Typography>
              <Typography variant="body1" className="capitalize">{selectedUser.provider}</Typography>
            </div>
            <div>
              <Typography variant="caption" className="text-gray-400">Status</Typography>
              <Badge variant={selectedUser.status === 'active' ? 'success' : 'danger'}>
                {selectedUser.status}
              </Badge>
            </div>
            <Flex gap="sm" className="pt-4">
              <Button variant="outline" fullWidth>Edit</Button>
              <Button variant="danger" fullWidth>Ban User</Button>
            </Flex>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default Users;
