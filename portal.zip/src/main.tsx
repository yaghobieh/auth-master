import React from 'react';
import ReactDOM from 'react-dom/client';
import '@forgedevstack/bear/styles.css';
import '@forgedevstack/grid-table/grid-table.css';
import { BrowserRouter } from 'react-router-dom';
import { BearProvider } from '@forgedevstack/bear';
import { AuthProvider } from '@forgedevstack/forge-auth';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <BrowserRouter>
      <BearProvider defaultMode="dark">
        <AuthProvider config={{ logLevel: 'debug' }}>
          <App />
        </AuthProvider>
      </BearProvider>
    </BrowserRouter>
  </React.StrictMode>
);
