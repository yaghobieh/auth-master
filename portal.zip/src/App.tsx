import React from 'react';
import { Routes, Route, Link, Outlet, Navigate } from 'react-router-dom';
import { useAuth, AuthGuard } from '@forgedevstack/forge-auth';
import { Typography, Button, useBear } from '@forgedevstack/bear';
import Dashboard from './pages/Dashboard';
import Users from './pages/Users';
import Logs from './pages/Logs';
import Settings from './pages/Settings';
import Login from './pages/Login';

const SidebarItem: React.FC<{ to: string; icon: string; label: string }> = ({ to, icon, label }) => (
  <Link
    to={to}
    className="flex items-center gap-3 px-4 py-3 text-gray-300 hover:bg-gray-800 hover:text-white rounded-lg transition-colors"
  >
    <span className="text-xl">{icon}</span>
    <span>{label}</span>
  </Link>
);

const PortalLayout: React.FC = () => {
  const { user, signOut } = useAuth();
  const { mode, toggleMode } = useBear();

  return (
    <div className="flex min-h-screen bg-gray-900">
      {/* Sidebar */}
      <aside className="w-64 border-r border-gray-800 bg-gray-900/50">
        <div className="flex items-center gap-2 px-4 py-4 border-b border-gray-800">
          <span className="text-2xl">🔐</span>
          <Typography variant="h6" className="gradient-text font-bold">
            AuthMaster
          </Typography>
        </div>
        <nav className="p-2 space-y-1">
          <SidebarItem to="/dashboard" icon="📊" label="Dashboard" />
          <SidebarItem to="/users" icon="👥" label="Users" />
          <SidebarItem to="/logs" icon="📋" label="Auth Logs" />
          <SidebarItem to="/settings" icon="⚙️" label="Settings" />
        </nav>
      </aside>
      
      {/* Main content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="flex items-center justify-between px-6 py-3 border-b border-gray-800 bg-gray-900/50">
          <Typography variant="h6">Portal</Typography>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={toggleMode}>
              {mode === 'dark' ? '☀️' : '🌙'}
            </Button>
            {user && (
              <div className="flex items-center gap-3">
                <span className="text-sm text-gray-400">{user.email}</span>
                <Button variant="outline" size="sm" onClick={signOut}>
                  Sign Out
                </Button>
              </div>
            )}
          </div>
        </header>
        
        {/* Page content */}
        <main className="flex-1 p-6 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      
      <Route
        path="/"
        element={
          <AuthGuard fallback={<Navigate to="/login" replace />}>
            <PortalLayout />
          </AuthGuard>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="users" element={<Users />} />
        <Route path="logs" element={<Logs />} />
        <Route path="settings" element={<Settings />} />
      </Route>
    </Routes>
  );
};

export default App;
